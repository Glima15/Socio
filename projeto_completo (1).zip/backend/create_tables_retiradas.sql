-- Tabela: retiradas

CREATE TABLE IF NOT EXISTS retiradas (
    id UUID PRIMARY KEY,
    socio_id UUID NOT NULL,
    empresa_id UUID NOT NULL,
    valor NUMERIC(12, 2) NOT NULL,
    data DATE NOT NULL,
    descricao TEXT,
    destino VARCHAR(100),
    tipo_transacao VARCHAR(50)
);