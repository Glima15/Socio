import pytest
from fastapi.testclient import TestClient
from main import app, get_db
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from main import Base

# Banco de dados de teste em memória
SQLALCHEMY_DATABASE_URL = "sqlite:///:memory:"
engine = create_engine(SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False})
TestingSessionLocal = sessionmaker(bind=engine)

# Criar tabelas
Base.metadata.create_all(bind=engine)

# Dependency override
def override_get_db():
    db = TestingSessionLocal()
    try:
        yield db
    finally:
        db.close()

app.dependency_overrides[get_db] = override_get_db
client = TestClient(app)

def test_login():
    response = client.post("/token", data={"username": "edgar@example.com", "password": "1234"})
    assert response.status_code == 200
    assert "access_token" in response.json()

def test_criar_retirada():
    login = client.post("/token", data={"username": "edgar@example.com", "password": "1234"})
    token = login.json()["access_token"]
    headers = {"Authorization": f"Bearer {token}"}

    payload = {
        "socio_id": "11111111-1111-1111-1111-111111111111",
        "empresa_id": "22222222-2222-2222-2222-222222222222",
        "valor": 1000.50,
        "data": "2024-04-01",
        "descricao": "Teste de retirada",
        "destino": "Conta Pessoal",
        "tipo_transacao": "PIX"
    }

    response = client.post("/retiradas", json=payload, headers=headers)
    assert response.status_code == 200
    assert response.json()["valor"] == 1000.50

def test_listar_retiradas():
    login = client.post("/token", data={"username": "edgar@example.com", "password": "1234"})
    token = login.json()["access_token"]
    headers = {"Authorization": f"Bearer {token}"}

    response = client.get("/retiradas", headers=headers)
    assert response.status_code == 200
    assert isinstance(response.json(), list)